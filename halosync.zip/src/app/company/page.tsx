import Container from '@/components/common/Container';
import Company from './Company';

export default function Sub3() {
  return (
    <Container>
      <Company />
    </Container>
  );
}
