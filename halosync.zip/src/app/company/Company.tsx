import InnerBasic from '@/components/common/InnerBasic';

export default function Company() {
  return (
    <InnerBasic>
      <div>SubPage333</div>
    </InnerBasic>
  );
}
