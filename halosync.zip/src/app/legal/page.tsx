import { redirect } from 'next/navigation';
// import Image from "next/image";

export default function LegalPage() {
  redirect('/legal/policy');
}
