import InnerBasic from '@/components/common/InnerBasic';

export default function Resources() {
  return (
    <InnerBasic>
      <div>SubPage22</div>
    </InnerBasic>
  );
}
