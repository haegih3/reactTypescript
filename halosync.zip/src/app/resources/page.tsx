import Container from '@/components/common/Container';
import Resources from './Resources';
// import Image from "next/image";

export default function Sub2() {
  return (
    <Container>
      <Resources />
    </Container>
  );
}
