import Container from '@/components/common/Container';
import Solution from './Solution';
// import Image from "next/image";

export default function Sub1() {
  return (
    <Container>
      <Solution />
    </Container>
  );
}
